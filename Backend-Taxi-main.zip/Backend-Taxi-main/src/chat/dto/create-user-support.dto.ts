// src/chat/dto/create-user-support.dto.ts
export class CreateUserSupportDto {
  // пустой DTO
}